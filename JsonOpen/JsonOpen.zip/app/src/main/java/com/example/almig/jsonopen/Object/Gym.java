package com.example.almig.jsonopen.Object;

public class Gym {
	private String manageOrgan;
	private String addr;
	private String centerName;
	private String tel;
	private String url;
	public String getManageOrgan() {
		return manageOrgan;
	}
	public void setManageOrgan(String manageOrgan) {
		this.manageOrgan = manageOrgan;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
}
